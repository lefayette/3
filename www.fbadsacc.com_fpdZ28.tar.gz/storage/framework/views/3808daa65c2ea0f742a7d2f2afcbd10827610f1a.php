<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="page-title-box">
            
            <h4 class="page-title"><?php echo e(__('hyper.bill_title'), false); ?></h4>
        </div>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="card card-body">
        	<div class="mx-auto">
        	    
                <div class="mb-1"><label><?php echo e(__('hyper.bill_order_number'), false); ?>：</label><span><?php echo e($order_sn, false); ?></span></div>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_product_name'), false); ?>：</label><span><?php echo e($title, false); ?></span></div>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_commodity_price'), false); ?>：</label><span><?php echo e($goods_price, false); ?></span></div>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_purchase_quantity'), false); ?>：</label><span>x <?php echo e($buy_amount, false); ?></span></div>
                <?php if(!empty($coupon)): ?>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_promo_code'), false); ?>：</label><span><?php echo e($coupon['coupon'], false); ?></span></div>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_discounted_price'), false); ?>：</label><span><?php echo e($coupon_discount_price, false); ?></span></div>
                <?php endif; ?>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_actual_payment'), false); ?>：</label><span><?php echo e($actual_price, false); ?></span></div>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_email'), false); ?>：</label><span><?php echo e($email, false); ?></span></div>
                <?php if(!empty($info)): ?>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_order_information'), false); ?>：</label><span><?php echo e($info, false); ?></span></div>
                <?php endif; ?>
                
                <div class="mb-1"><label><?php echo e(__('hyper.bill_payment_method'), false); ?>：</label><span><?php echo e($pay['pay_name'], false); ?></span></div>
            </div>
            <div class="text-center">
                
            	<a href="<?php echo e(url('pay-gateway', ['handle' => urlencode($pay['pay_handleroute']),'payway' => $pay['pay_check'], 'orderSN' => $order_sn]), false); ?>"
                   class="btn btn-danger">
                    <?php echo e(__('hyper.bill_pay_immediately'), false); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hyper.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/hyper/static_pages/bill.blade.php ENDPATH**/ ?>