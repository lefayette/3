
<?php $__env->startSection('content'); ?>

    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">

            <div class="layui-card cardcon">
                <div class="layui-card-header"><?php echo e(__('dujiaoka.scan_qrcode_to_pay'), false); ?></div>

                <div class="layui-card-body">
                    <div class="product-info">
                        <p style="color: #1E9FFF;font-size: 20px;font-weight: 500; text-align: center" ><?php echo e(__('dujiaoka.payment_method'), false); ?>：[<?php echo e($payname, false); ?>], <?php echo e(__('dujiaoka.pay_order_expiration_date_prompt', ['min' => dujiaoka_config_get('order_expire_time', 5)]), false); ?></p>
                    </div>
                    <div style="text-align: center; width: 100%;">
                    <p class="product-pay-price"><?php echo e(__('dujiaoka.amount_to_be_paid'), false); ?>: <?php echo e($actual_price, false); ?></p>
                    <img  src="data:image/png;base64,<?php echo base64_encode(QrCode::format('png')->size(200)->generate($qr_code)); ?>">
                    </div>
                    <?php if(Agent::isMobile() && isset($jump_payuri)): ?>
                        <p class="errpanl" style="text-align: center"><a href="<?php echo e($jump_payuri, false); ?>" class="layui-btn layui-btn-warm layui-btn-sm"><?php echo e(__('dujiaoka.open_the_app_to_pay'), false); ?></a></p>
                    <?php endif; ?>
                </div>



            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('tpljs'); ?>
    <script>
        layui.use(['layer'], function(){
            var getting = {
                url:'<?php echo e(url('check-order-status', ['orderSN' => $orderid]), false); ?>',
                dataType:'json',
                success:function(res) {
                    if (res.code == 400001) {
                        window.clearTimeout(timer);
                        layer.alert("<?php echo e(__('dujiaoka.prompt.order_is_expired'), false); ?>", {
                            icon: 2
                        }, function(){
                            window.location.href = '/'
                        });
                    }
                    if (res.code == 200) {
                        window.clearTimeout(timer);
                        layer.alert("<?php echo e(__('dujiaoka.prompt.payment_successful'), false); ?>", {
                            icon: 1,
                            closeBtn:0
                        }, function(){
                            window.location.href = "<?php echo e(url('detail-order-sn', ['orderSN' => $orderid]), false); ?>"
                        });
                    }
                }

            };
            var timer = window.setInterval(function(){$.ajax(getting)},5000);
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layui.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/layui/static_pages/qrpay.blade.php ENDPATH**/ ?>