<div class="sh-notice">

    <div class="layui-row ">
        <!-- PC -->
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">
            <div class="layui-card cardcon">
                <div class="layui-card-header"><?php echo e(__('dujiaoka.site_announcement'), false); ?>：</div>
                <div class="layui-card-body">
                    <?php echo dujiaoka_config_get('notice'); ?>

                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/layui/layouts/_notice.blade.php ENDPATH**/ ?>