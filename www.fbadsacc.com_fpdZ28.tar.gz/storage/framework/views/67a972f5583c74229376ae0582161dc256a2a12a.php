<?php $__env->startSection('notice'); ?>
<?php echo $__env->make('layui.layouts._notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="layui-row">
            <div class="layui-col-md8 layui-col-md-offset2 layui-col-xs12">
                <div class="layui-card cardcon">
                    <div class="layui-card-header"><?php echo e($group['gp_name'], false); ?>：</div>
                    <div class="layui-card-body">
                        <div class="layui-row" >
                            <table class="layui-table" lay-even lay-skin="nob">
                                <colgroup>
                                    <col width="300">
                                    <col width="100">
                                    <col>
                                    <col>
                                    <col>
                                    <col>
                                    <col>
                                </colgroup>
                                <thead>
                                <tr>
                                    <th><?php echo e(__('goods.fields.gd_name'), false); ?></th>
                                    <th><?php echo e(__('goods.fields.group_id'), false); ?></th>
                                    <th><?php echo e(__('dujiaoka.price'), false); ?></th>
                                    <th><?php echo e(__('goods.fields.in_stock'), false); ?></th>
                                    <th><?php echo e(__('dujiaoka.wholesale_discount'), false); ?></th>
                                    <th><?php echo e(__('dujiaoka.order_now'), false); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $group['goods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($goods['gd_name'], false); ?></td>
                                        <td>
                                            <?php if($goods['type'] == \App\Models\Goods::AUTOMATIC_DELIVERY): ?>
                                                <span style="color: #5FB878"><?php echo e(__('goods.fields.automatic_delivery'), false); ?></span>
                                            <?php else: ?>
                                                <span style="color: #FF5722"><?php echo e(__('goods.fields.manual_processing'), false); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><b class="product-box-price"><?php echo e(__('dujiaoka.money_symbol'), false); ?><?php echo e($goods['actual_price'], false); ?></b></td>
                                        <td><?php echo e($goods['in_stock'], false); ?></td>
                                        <td><?php if($goods['wholesale_price_cnf']): ?>
                                                <span class="layui-badge layui-bg-orange"><?php echo e(__('dujiaoka.discount'), false); ?></span>
                                            <?php else: ?>
                                                <span class="layui-badge"><?php echo e(__('dujiaoka.not'), false); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($goods['in_stock'] > 0): ?>
                                            <a href="<?php echo e(url("/buy/{$goods['id']}"), false); ?>" class="layui-btn layui-btn-radius layui-btn-primary layui-btn-sm">
                                                <?php echo e(__('dujiaoka.order_now'), false); ?><i class="layui-icon layui-icon-cart-simple"></i>
                                            </a>
                                            <?php else: ?>
                                                <a href="#" class="layui-btn layui-btn-radius layui-btn-disabled layui-btn-sm">
                                                    <?php echo e(__('dujiaoka.order_now'), false); ?><i class="layui-icon layui-icon-cart-simple"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layui.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/layui/static_pages/home.blade.php ENDPATH**/ ?>