<div class="row">
	<div class="col-12">
        <div class="card">
            <div class="card-body">
            	<h4 class="card-title mb-3"><?php echo e(__('hyper.notice_announcement'), false); ?></h4>
                <?php echo dujiaoka_config_get('notice'); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/hyper/layouts/_notice.blade.php ENDPATH**/ ?>