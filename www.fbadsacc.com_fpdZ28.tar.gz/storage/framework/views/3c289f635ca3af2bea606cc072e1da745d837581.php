<?php echo $body; ?>

<?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/email/mail.blade.php ENDPATH**/ ?>