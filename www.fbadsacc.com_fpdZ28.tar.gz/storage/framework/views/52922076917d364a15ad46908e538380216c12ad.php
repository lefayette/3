<div class="main layui-hide-xs">
  <div class="layui-row">
    <div class="layui-col-sm12">
        <div class="main-box">
        <div class="title">
              <p class="tit"><?php echo e(__('dujiaoka.site_announcement'), false); ?>:</p>
          </div>
          <div class="goods">
              <div class="tips"><?php echo dujiaoka_config_get('notice'); ?></div>
          </div>
      </div>
    </div>
  </div>
</div><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/luna/layouts/_notice_xs.blade.php ENDPATH**/ ?>