
<?php $__env->startSection('content'); ?>

    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">

            <div class="layui-card cardcon">
                <div class="layui-card-header"><?php echo e(__('dujiaoka.confirm_order'), false); ?></div>

                <div class="layui-card-body">
                    <div class="product-info">
                        <p style="color: #1E9FFF;font-size: 20px;font-weight: 500; text-align: center" ><?php echo e(__('dujiaoka.warning_title'), false); ?><?php echo e(__('dujiaoka.date_to_expired_order', ['min' => dujiaoka_config_get('order_expire_time', 5)]), false); ?></p>
                    </div>
                    <table class="layui-table" lay-skin="" >
                        <colgroup>
                            <col width="100">
                            <col width="150">
                        </colgroup>
                        <tbody>
                        <tr>
                            <td><?php echo e(__('order.fields.order_sn'), false); ?>：</td>
                            <td><?php echo e($order_sn, false); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('order.fields.title'), false); ?>：</td>
                            <td>
                                <span class="layui-badge layui-bg-blue">
                                    <?php echo e($title, false); ?>

                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('order.fields.goods_price'), false); ?>：</td>
                            <td>
                                <span class="layui-badge layui-bg-orange">
                                    <?php echo e($goods_price, false); ?>

                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('order.fields.buy_amount'), false); ?>：</td>
                            <td>x <?php echo e($buy_amount, false); ?></td>
                        </tr>
                        <?php if(!empty($coupon)): ?>
                        <tr>
                            <td><?php echo e(__('order.fields.coupon_id'), false); ?>：</td>
                            <td><span class="layui-badge layui-bg-orange"><?php echo e($coupon['coupon'], false); ?></span></td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('order.fields.coupon_discount_price'), false); ?>：</td>
                            <td> <span class="layui-badge layui-bg-green"><?php echo e(__('dujiaoka.money_symbol'), false); ?><?php echo e($coupon_discount_price, false); ?></span></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($wholesale_discount_price > 0 ): ?>
                            <tr>
                                <td><?php echo e(__('order.fields.wholesale_discount_price'), false); ?>：</td>
                                <td> <span class="layui-badge layui-bg-green"><?php echo e(__('dujiaoka.money_symbol'), false); ?><?php echo e($wholesale_discount_price, false); ?></span></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td><?php echo e(__('order.fields.actual_price'), false); ?>：</td>
                            <td><span class="layui-badge layui-bg-red"><?php echo e(__('dujiaoka.money_symbol'), false); ?><?php echo e($actual_price, false); ?></span></td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('dujiaoka.email'), false); ?>：</td>
                            <td><?php echo e($email, false); ?></td>
                        </tr>
                        <?php if(!empty($info)): ?>
                        <tr>
                            <td><?php echo e(__('dujiaoka.order_information'), false); ?>:</td>
                            <td><p><?php echo e($info, false); ?></p></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td><?php echo e(__('dujiaoka.payment_method'), false); ?>：</td>
                            <td><?php echo e($pay['pay_name'], false); ?></td>
                        </tr>
                        </tbody>
                    </table>
                    <p class="errpanl" style="text-align: center"><a href="<?php echo e(url('pay-gateway', ['handle' => urlencode($pay['pay_handleroute']),'payway' => $pay['pay_check'], 'orderSN' => $order_sn]), false); ?>" class="layui-btn layui-btn-sm"><?php echo e(__('dujiaoka.pay_immediately'), false); ?></a></p>

                </div>

            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('tpljs'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layui.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/layui/static_pages/bill.blade.php ENDPATH**/ ?>