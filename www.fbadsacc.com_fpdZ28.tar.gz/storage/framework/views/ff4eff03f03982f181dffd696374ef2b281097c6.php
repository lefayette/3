
<?php $__env->startSection('content'); ?>

    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">

            <div class="layui-card cardcon">
                <div class="layui-card-header"><?php echo e(__('order.fields.order_detail'), false); ?></div>

                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="layui-card-body info-box">
                    <div class="layui-row order-list">

                            <div class="layui-col-md4">
                                <ul class="info-ui">
                                    <li>
                                        <strong><?php echo e(__('order.fields.order_sn'), false); ?>:</strong>
                                        <?php echo e($order['order_sn'], false); ?>

                                    </li>
                                    <li>
                                        <strong><?php echo e(__('order.fields.title'), false); ?>:</strong>
                                       <?php echo e($order['title'], false); ?>

                                    </li>
                                    <li><strong><?php echo e(__('order.fields.buy_amount'), false); ?>:</strong> <?php echo e($order['buy_amount'], false); ?></li>
                                    <li><strong><?php echo e(__('order.fields.order_created'), false); ?>:</strong> <?php echo e($order['created_at'], false); ?>

                                    </li>
                                    <li><strong><?php echo e(__('order.fields.email'), false); ?>:</strong> <?php echo e($order['email'], false); ?></li>
                                </ul>
                            </div>
                            <div class="layui-col-md4">
                                <ul class="info-ui">
                                    <li><strong><?php echo e(__('order.fields.type'), false); ?>:</strong>
                                        <?php if($order['type'] == \App\Models\Order::AUTOMATIC_DELIVERY): ?>
                                            <span class="layui-badge layui-bg-green"><?php echo e(__('goods.fields.automatic_delivery'), false); ?></span>
                                        <?php else: ?>
                                            <span class="layui-badge layui-bg-orange"><?php echo e(__('goods.fields.manual_processing'), false); ?></span>
                                        <?php endif; ?>
                                    </li>
                                    <li><strong><?php echo e(__('order.fields.actual_price'), false); ?>:</strong>  <span class="layui-badge layui-bg-blue"><?php echo e($order['actual_price'], false); ?></span></li>
                                    <li><strong><?php echo e(__('order.fields.status'), false); ?>:</strong> <!----> <!---->

                                            <?php switch($order['status']):
                                                case (\App\Models\Order::STATUS_EXPIRED): ?>
                                                    <span class="layui-badge layui-bg-cyan"><?php echo e(__('order.fields.status_expired'), false); ?></span>
                                                    <?php break; ?>
                                                <?php case (\App\Models\Order::STATUS_WAIT_PAY): ?>
                                                    <span class="layui-badge layui-bg-blue"><?php echo e(__('order.fields.status_wait_pay'), false); ?></span>
                                                    <?php break; ?>
                                                <?php case (\App\Models\Order::STATUS_PENDING): ?>
                                                    <span class="layui-badge layui-bg-green"><?php echo e(__('order.fields.status_pending'), false); ?></span>
                                                 <?php break; ?>
                                                <?php case (\App\Models\Order::STATUS_PROCESSING): ?>
                                                    <span class="layui-badge layui-bg-green"><?php echo e(__('order.fields.status_processing'), false); ?></span>
                                                <?php break; ?>
                                                <?php case (\App\Models\Order::STATUS_COMPLETED): ?>
                                                    <span class="layui-badge layui-bg-green"><?php echo e(__('order.fields.status_completed'), false); ?></span>
                                                <?php break; ?>
                                                <?php case (\App\Models\Order::STATUS_FAILURE): ?>
                                                    <span class="layui-badge layui-bg-black"><?php echo e(__('order.fields.status_failure'), false); ?></span>
                                                    <?php break; ?>
                                                <?php case (\App\Models\Order::STATUS_ABNORMAL): ?>
                                                    <span class="layui-badge layui-bg-black"><?php echo e(__('order.fields.status_abnormal'), false); ?></span>
                                                <?php break; ?>
                                            <?php endswitch; ?>
                                    </li>
                                    <li><strong><?php echo e(__('dujiaoka.payment_method'), false); ?>:</strong> <?php echo e($order['pay']['pay_name'] ?? '', false); ?></li>
                                </ul>
                            </div>
                            <div class="layui-col-md4">
                                <div class="order-info">
                                    <?php echo str_replace(PHP_EOL, '<br/>', $order['info']); ?>

                                </div>
                                <button type="button"  class="layui-btn layui-btn-normal" data-clipboard-text="<?php echo e($order['info'], false); ?>" style="width: 100%"><?php echo e(__('dujiaoka.copy_text'), false); ?></button>
                            </div>
                        </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('tpljs'); ?>
    <script>

        layui.use('layer', function(){
            var layer = layui.layer //获得layer模块
            var clipboard = new ClipboardJS('.layui-btn');
            clipboard.on('success', function(e) {
                layer.msg("<?php echo e(__('dujiaoka.prompt.copy_text_success'), false); ?>");

            });
            clipboard.on('error', function(e) {
                layer.msg("<?php echo e(__('dujiaoka.prompt.copy_text_failed'), false); ?>");
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layui.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/layui/static_pages/orderinfo.blade.php ENDPATH**/ ?>