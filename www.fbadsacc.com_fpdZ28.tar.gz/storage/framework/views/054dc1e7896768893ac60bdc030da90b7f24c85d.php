<script src="/assets/hyper/js/jquery-3.4.1.min.js"></script>
<script src="/assets/hyper/js/vendor.min.js"></script>
<script src="/assets/hyper/js/app.min.js"></script>
<script src="/assets/hyper/js/hyper.js?v=215115"></script><?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/hyper/layouts/_script.blade.php ENDPATH**/ ?>