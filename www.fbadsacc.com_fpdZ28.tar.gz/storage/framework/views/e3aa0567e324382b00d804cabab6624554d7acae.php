<script>
    let tipsMsg = {
        least_one    : '<?php echo e(__('layui.least_one'), false); ?>',
        exceeds      : '<?php echo e(__('layui.exceeds'), false); ?>',
        exceeds_limit: '<?php echo e(__('layui.exceeds_limit'), false); ?>',
        mobile_order : '<?php echo e(__('layui.mobile_order'), false); ?>'
    };
</script>
<script src="/assets/layui/layui/layui.js"></script>
<script src="/assets/layui/js/jquery-3.4.1.min.js"></script>
<script src="/assets/layui/main.js"></script>
<script src="/assets/layui/layui/lay/modules/layer.js"></script>
<?php /**PATH /www/wwwroot/www.fbadsacc.com/resources/views/layui/layouts/_script.blade.php ENDPATH**/ ?>